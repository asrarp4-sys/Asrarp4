# H Kabir Fabric Website

This is a simple mobile-friendly starter website.

Files:
- index.html
- style.css
- script.js

Before publishing, replace:
- "Add your WhatsApp number"
- "Add your phone number"
- "Add your shop address"
- Sample fabric boxes with real fabric photos
