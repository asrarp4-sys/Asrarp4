// H Kabir Fabric - simple starter website
console.log("H Kabir Fabric website loaded.");
